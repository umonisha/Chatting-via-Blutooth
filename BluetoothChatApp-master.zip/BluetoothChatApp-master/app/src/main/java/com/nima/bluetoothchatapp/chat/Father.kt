package com.nima.bluetoothchatapp.chat

data class Father(
    var id:Int
) {
    override fun toString(): String {
        return "Father(id=$id)"
    }
}